(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;

/* Package-scope variables */
var App;

(function(){

////////////////////////////////////////////////////////////////////////
//                                                                    //
// packages/app-root/lib/base_all.js                                  //
//                                                                    //
////////////////////////////////////////////////////////////////////////
                                                                      //
App = {};         // root of all evil

App.Consts = {};  // define meaningless const
App.Consts.APP_NAME = "Submarine";
App.Consts.ServerUTCOffset = -480; // PST slower then UTC 8h

App.Utils = {}        // for Front-End Helper, utility functions
App.Services = {};     // For middleware, connecting client - server
App.Collections = {}; // For database objects
App.Schemas = {};     // For database plots

// TODO add specified features under App.Service
App.Services.Users = {};  // All user essential items


////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////
//                                                                    //
// packages/app-root/lib/base_server.js                               //
//                                                                    //
////////////////////////////////////////////////////////////////////////
                                                                      //
/**
 * Namespace can only be viewed on server
 */

App.Seeder = {};      // seed empty database
App.Initializer = {}; // initialize server object ex: email template 
App.CronJobs = {};    // Contain chronic jobs need to be done 

////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['app-root'] = {}, {
  App: App
});

})();

//# sourceMappingURL=app-root.js.map
