var require = meteorInstall({"common":{"collections":{"message.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// common/collections/message.js                                                                                    //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
App.Collections.Message = new Mongo.Collection('message');                                                          // 1
                                                                                                                    //
var messageSchema = {                                                                                               // 3
                                                                                                                    //
    is_public: {                                                                                                    // 5
        type: Boolean,                                                                                              // 6
        optional: true                                                                                              // 7
    },                                                                                                              // 5
                                                                                                                    //
    sender: {                                                                                                       // 10
        type: String,                                                                                               // 11
        optional: true,                                                                                             // 12
        label: "user id"                                                                                            // 13
    },                                                                                                              // 10
    receiver: {                                                                                                     // 15
        type: String,                                                                                               // 16
        optional: true                                                                                              // 17
    },                                                                                                              // 15
    message: {                                                                                                      // 19
        type: String,                                                                                               // 20
        optional: true                                                                                              // 21
    },                                                                                                              // 19
    time: {                                                                                                         // 23
        type: Date,                                                                                                 // 24
        optional: true                                                                                              // 25
    },                                                                                                              // 23
    rate: {                                                                                                         // 27
        type: Number,                                                                                               // 28
        optional: true                                                                                              // 29
    }                                                                                                               // 27
};                                                                                                                  // 3
                                                                                                                    //
// attach the schema                                                                                                //
App.Schemas.Message = new SimpleSchema(messageSchema);                                                              // 34
App.Collections.Message.attachSchema(App.Schemas.Message);                                                          // 35
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"settings.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// common/collections/settings.js                                                                                   //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
App.Collections.Settings = new Mongo.Collection('settings');                                                        // 1
                                                                                                                    //
var settingSchema = {                                                                                               // 3
  smtpAddress: {                                                                                                    // 4
    type: String,                                                                                                   // 5
    optional: true                                                                                                  // 6
  },                                                                                                                // 4
  smtpPort: {                                                                                                       // 8
    type: String,                                                                                                   // 9
    optional: true                                                                                                  // 10
  },                                                                                                                // 8
  smtpUsername: {                                                                                                   // 12
    type: String,                                                                                                   // 13
    optional: true                                                                                                  // 14
  },                                                                                                                // 12
  smtpPassword: {                                                                                                   // 16
    type: String,                                                                                                   // 17
    optional: true                                                                                                  // 18
  },                                                                                                                // 16
  smtpAuthentication: {                                                                                             // 20
    type: String,                                                                                                   // 21
    optional: true                                                                                                  // 22
  }                                                                                                                 // 20
};                                                                                                                  // 3
                                                                                                                    //
// attach the schema                                                                                                //
App.Schemas.Settings = new SimpleSchema(settingSchema);                                                             // 27
App.Collections.Settings.attachSchema(App.Schemas.Settings);                                                        // 28
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"tags.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// common/collections/tags.js                                                                                       //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
App.Collections.Tags = new Mongo.Collection('tags');                                                                // 1
                                                                                                                    //
var tagSchema = {                                                                                                   // 3
  name: {                                                                                                           // 4
    type: String,                                                                                                   // 5
    optional: true                                                                                                  // 6
  },                                                                                                                // 4
  description: {                                                                                                    // 8
    type: String,                                                                                                   // 9
    optional: true                                                                                                  // 10
  },                                                                                                                // 8
  wifis: {                                                                                                          // 12
    type: Array,                                                                                                    // 13
    optional: true,                                                                                                 // 14
    label: "array of wifi id under this tag"                                                                        // 15
  },                                                                                                                // 12
  "wifis.$": {                                                                                                      // 17
    type: Object,                                                                                                   // 18
    optional: true                                                                                                  // 19
  },                                                                                                                // 17
  "wifis.$.wifiId": {                                                                                               // 21
    type: String,                                                                                                   // 22
    optional: true                                                                                                  // 23
  },                                                                                                                // 21
  "wifis.$.level": {                                                                                                // 25
    type: Number,                                                                                                   // 26
    optional: true                                                                                                  // 27
  },                                                                                                                // 25
  users: {                                                                                                          // 29
    type: Array,                                                                                                    // 30
    optional: true,                                                                                                 // 31
    label: "array of user id under this tag"                                                                        // 32
  },                                                                                                                // 29
  "users.$": {                                                                                                      // 34
    type: String,                                                                                                   // 35
    optional: true                                                                                                  // 36
  },                                                                                                                // 34
  activeUser: {                                                                                                     // 38
    type: Array,                                                                                                    // 39
    optional: true,                                                                                                 // 40
    label: "array of current in ranged user"                                                                        // 41
  },                                                                                                                // 38
  "activeUser.$": {                                                                                                 // 43
    type: String,                                                                                                   // 44
    optional: true                                                                                                  // 45
  },                                                                                                                // 43
  startTime: {                                                                                                      // 47
    type: Number,                                                                                                   // 48
    optional: true                                                                                                  // 49
  },                                                                                                                // 47
  duration: {                                                                                                       // 51
    type: Number,                                                                                                   // 52
    optional: true                                                                                                  // 53
  },                                                                                                                // 51
  repeat: {                                                                                                         // 55
    type: Number,                                                                                                   // 56
    optional: true,                                                                                                 // 57
    label: "a number that indicates what days the tag becomes active"                                               // 58
  }                                                                                                                 // 55
};                                                                                                                  // 3
                                                                                                                    //
// attach the schema                                                                                                //
App.Schemas.Tags = new SimpleSchema(tagSchema);                                                                     // 63
App.Collections.Tags.attachSchema(App.Schemas.Tags);                                                                // 64
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"users.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// common/collections/users.js                                                                                      //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
App.Schemas.UserProfile = new SimpleSchema({                                                                        // 1
  profileSeed: {                                                                                                    // 2
    type: String,                                                                                                   // 3
    optional: true,                                                                                                 // 4
    label: "random seed that generates the profile picture"                                                         // 5
  },                                                                                                                // 2
                                                                                                                    //
  friendRequest: {                                                                                                  // 8
    type: Array,                                                                                                    // 9
    optional: true,                                                                                                 // 10
    label: "Array of users who send friend request to this user, include userId, requestReason"                     // 11
  },                                                                                                                // 8
                                                                                                                    //
  "friendRequest.$": {                                                                                              // 14
    type: Object,                                                                                                   // 15
    optional: true                                                                                                  // 16
  },                                                                                                                // 14
                                                                                                                    //
  "friendRequest.$.userId": {                                                                                       // 19
    type: String,                                                                                                   // 20
    optional: true                                                                                                  // 21
  },                                                                                                                // 19
                                                                                                                    //
  "friendRequest.$.requestReason": {                                                                                // 24
    type: String,                                                                                                   // 25
    optional: true,                                                                                                 // 26
    label: "Why want to add friends"                                                                                // 27
  },                                                                                                                // 24
                                                                                                                    //
  recommendedFriends: {                                                                                             // 30
    type: Array,                                                                                                    // 31
    optional: true,                                                                                                 // 32
    label: "Array of recommendedFriends to user, include userId, user name, profile seed"                           // 33
  },                                                                                                                // 30
                                                                                                                    //
  "recommendedFriends.$": {                                                                                         // 36
    type: Object,                                                                                                   // 37
    optional: true                                                                                                  // 38
  },                                                                                                                // 36
                                                                                                                    //
  "recommendedFriends.$.userId": {                                                                                  // 41
    type: String,                                                                                                   // 42
    optional: true                                                                                                  // 43
  },                                                                                                                // 41
                                                                                                                    //
  "recommendedFriends.$.recommendReason": {                                                                         // 46
    type: String,                                                                                                   // 47
    optional: true,                                                                                                 // 48
    label: "String of common chatroom of 2 users"                                                                   // 49
  },                                                                                                                // 46
                                                                                                                    //
  turndownFriends: {                                                                                                // 52
    type: Array,                                                                                                    // 53
    optional: true,                                                                                                 // 54
    label: "array of turn down friend request, future request will be blocked to some time"                         // 55
  },                                                                                                                // 52
                                                                                                                    //
  "turndownFriends.$": {                                                                                            // 58
    type: Object,                                                                                                   // 59
    optional: true                                                                                                  // 60
  },                                                                                                                // 58
                                                                                                                    //
  "turndownFriends.$.userId": {                                                                                     // 63
    type: String,                                                                                                   // 64
    optional: true                                                                                                  // 65
  },                                                                                                                // 63
                                                                                                                    //
  "turndownFriends.$.validThru": {                                                                                  // 68
    type: Date,                                                                                                     // 69
    optional: true                                                                                                  // 70
  },                                                                                                                // 68
                                                                                                                    //
  friends: {                                                                                                        // 73
    type: Array,                                                                                                    // 74
    optional: true                                                                                                  // 75
  },                                                                                                                // 73
                                                                                                                    //
  "friends.$": {                                                                                                    // 78
    type: Object,                                                                                                   // 79
    optional: true                                                                                                  // 80
  },                                                                                                                // 78
                                                                                                                    //
  "friends.$.userId": {                                                                                             // 83
    type: String,                                                                                                   // 84
    optional: true                                                                                                  // 85
  },                                                                                                                // 83
                                                                                                                    //
  "friends.$.nickname": {                                                                                           // 88
    type: String,                                                                                                   // 89
    optional: true                                                                                                  // 90
  },                                                                                                                // 88
                                                                                                                    //
  strangers: {                                                                                                      // 93
    type: Array,                                                                                                    // 94
    optional: true,                                                                                                 // 95
    label: "Stranger that chats with user auto remove in certain time"                                              // 96
  },                                                                                                                // 93
                                                                                                                    //
  "strangers.$": {                                                                                                  // 99
    type: Object,                                                                                                   // 100
    optional: true                                                                                                  // 101
  },                                                                                                                // 99
                                                                                                                    //
  "strangers.$.userId": {                                                                                           // 104
    type: String,                                                                                                   // 105
    optional: true                                                                                                  // 106
  },                                                                                                                // 104
                                                                                                                    //
  "strangers.$.validThru": {                                                                                        // 109
    type: Date,                                                                                                     // 110
    optional: true                                                                                                  // 111
  },                                                                                                                // 109
                                                                                                                    //
  savedTags: {                                                                                                      // 114
    type: Array,                                                                                                    // 115
    optional: true,                                                                                                 // 116
    label: "user saved tag, can be accessed any time"                                                               // 117
  },                                                                                                                // 114
                                                                                                                    //
  "savedTags.$": {                                                                                                  // 120
    type: Object,                                                                                                   // 121
    optional: true                                                                                                  // 122
  },                                                                                                                // 120
                                                                                                                    //
  "savedTags.$.tagId": {                                                                                            // 125
    type: String,                                                                                                   // 126
    optional: true                                                                                                  // 127
  },                                                                                                                // 125
                                                                                                                    //
  "savedTags.$.validThru": {                                                                                        // 130
    type: Date,                                                                                                     // 131
    optional: true                                                                                                  // 132
  },                                                                                                                // 130
                                                                                                                    //
  "savedTags.$.calendar": {                                                                                         // 135
    type: Boolean,                                                                                                  // 136
    optional: true                                                                                                  // 137
  },                                                                                                                // 135
                                                                                                                    //
  socialMedia: {                                                                                                    // 140
    type: Object,                                                                                                   // 141
    optional: true,                                                                                                 // 142
    label: "store user social media info"                                                                           // 143
  },                                                                                                                // 140
                                                                                                                    //
  "socialMedia.facebook": {                                                                                         // 146
    type: String,                                                                                                   // 147
    optional: true                                                                                                  // 148
  },                                                                                                                // 146
                                                                                                                    //
  "socialMedia.google": {                                                                                           // 151
    type: String,                                                                                                   // 152
    optional: true                                                                                                  // 153
  },                                                                                                                // 151
                                                                                                                    //
  "socialMedia.github": {                                                                                           // 156
    type: String,                                                                                                   // 157
    optional: true                                                                                                  // 158
  }                                                                                                                 // 156
});                                                                                                                 // 1
                                                                                                                    //
App.Schemas.User = new SimpleSchema({                                                                               // 162
  username: {                                                                                                       // 163
    type: String,                                                                                                   // 164
    optional: true                                                                                                  // 165
  },                                                                                                                // 163
                                                                                                                    //
  emails: {                                                                                                         // 168
    type: Array,                                                                                                    // 169
    optional: true                                                                                                  // 170
  },                                                                                                                // 168
                                                                                                                    //
  "emails.$": {                                                                                                     // 173
    type: Object                                                                                                    // 174
  },                                                                                                                // 173
                                                                                                                    //
  "emails.$.address": {                                                                                             // 177
    type: String,                                                                                                   // 178
    regEx: SimpleSchema.RegEx.Email                                                                                 // 179
  },                                                                                                                // 177
                                                                                                                    //
  "emails.$.verified": {                                                                                            // 182
    type: Boolean                                                                                                   // 183
  },                                                                                                                // 182
                                                                                                                    //
  services: {                                                                                                       // 186
    type: Object,                                                                                                   // 187
    optional: true,                                                                                                 // 188
    blackbox: true                                                                                                  // 189
  },                                                                                                                // 186
                                                                                                                    //
  createdAt: {                                                                                                      // 192
    type: Date                                                                                                      // 193
  },                                                                                                                // 192
                                                                                                                    //
  profile: {                                                                                                        // 196
    type: App.Schemas.UserProfile,                                                                                  // 197
    optional: true,                                                                                                 // 198
    label: "user's profile, only field to auto publish to Client"                                                   // 199
  },                                                                                                                // 196
                                                                                                                    //
  allowBeRecommended: {                                                                                             // 202
    type: Boolean,                                                                                                  // 203
    optional: false,                                                                                                // 204
    label: "if user want to be recommaned to others as friends"                                                     // 205
  },                                                                                                                // 202
                                                                                                                    //
  recentTags: {                                                                                                     // 208
    type: Array,                                                                                                    // 209
    optional: true,                                                                                                 // 210
    label: "user saved tag, can be accessed any time"                                                               // 211
  },                                                                                                                // 208
                                                                                                                    //
  "recentTags.$": {                                                                                                 // 214
    type: Object,                                                                                                   // 215
    optional: true                                                                                                  // 216
  },                                                                                                                // 214
                                                                                                                    //
  "recentTags.$.tagId": {                                                                                           // 219
    type: String,                                                                                                   // 220
    optional: true                                                                                                  // 221
  },                                                                                                                // 219
                                                                                                                    //
  "recentTags.$.time": {                                                                                            // 224
    type: Date,                                                                                                     // 225
    optional: true                                                                                                  // 226
  },                                                                                                                // 224
                                                                                                                    //
  login_history: {                                                                                                  // 229
    type: Array,                                                                                                    // 230
    optional: true                                                                                                  // 231
  },                                                                                                                // 229
                                                                                                                    //
  "login_history.$": {                                                                                              // 234
    type: Date,                                                                                                     // 235
    optional: true                                                                                                  // 236
  },                                                                                                                // 234
                                                                                                                    //
  token: {                                                                                                          // 239
    type: String,                                                                                                   // 240
    optional: true,                                                                                                 // 241
    label: "user's android device token"                                                                            // 242
  },                                                                                                                // 239
                                                                                                                    //
  online: {                                                                                                         // 245
    type: Boolean,                                                                                                  // 246
    optional: true,                                                                                                 // 247
    label: "If the user is currently running the application"                                                       // 248
  }                                                                                                                 // 245
                                                                                                                    //
});                                                                                                                 // 162
                                                                                                                    //
// Meteor has its own user data base, only need to attach the Schemas                                               //
Meteor.users.attachSchema(App.Schemas.User);                                                                        // 254
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"wifis.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// common/collections/wifis.js                                                                                      //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
App.Collections.Wifis = new Mongo.Collection('wifis');                                                              // 1
                                                                                                                    //
var wifiSchema = {                                                                                                  // 3
                                                                                                                    //
  ssid: {                                                                                                           // 5
    type: String,                                                                                                   // 6
    optional: true                                                                                                  // 7
  },                                                                                                                // 5
  bssid: {                                                                                                          // 9
    type: String,                                                                                                   // 10
    optional: true                                                                                                  // 11
  },                                                                                                                // 9
  tags: {                                                                                                           // 13
    type: Array,                                                                                                    // 14
    optional: true,                                                                                                 // 15
    label: "array of ids of active_tags that are under this wifi"                                                   // 16
  },                                                                                                                // 13
  "tags.$": {                                                                                                       // 18
    type: String,                                                                                                   // 19
    optional: true                                                                                                  // 20
  }                                                                                                                 // 18
};                                                                                                                  // 3
                                                                                                                    //
// attach the schema                                                                                                //
App.Schemas.Wifis = new SimpleSchema(wifiSchema);                                                                   // 25
App.Collections.Wifis.attachSchema(App.Schemas.Wifis);                                                              // 26
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"methods":{"chats.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// common/methods/chats.js                                                                                          //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
Meteor.methods({                                                                                                    // 1
  "chats/sendMsg": function chatsSendMsg(msg) {                                                                     // 2
    App.Collections.Message.insert(msg);                                                                            // 3
                                                                                                                    //
    if (this.isSimulation) return;                                                                                  // 5
                                                                                                                    //
    App.Services.Notification.sendGCMNotification(msg);                                                             // 7
  },                                                                                                                // 8
                                                                                                                    //
  "chats/getHistory": function chatsGetHistory(targetId, oldestMsg, lastRead, isPublic, isNew) {                    // 10
    if (this.isSimulation) return;                                                                                  // 11
                                                                                                                    //
    // build selector                                                                                               //
    var now = new Date();                                                                                           // 14
                                                                                                                    //
    var selector = {                                                                                                // 16
      is_public: isPublic,                                                                                          // 17
      time: {                                                                                                       // 18
        $gt: oldestMsg > lastRead ? lastRead : new Date(0)                                                          // 19
      }                                                                                                             // 18
    };                                                                                                              // 16
                                                                                                                    //
    if (isNew) {                                                                                                    // 23
      selector.time.$lte = now;                                                                                     // 24
    } else {                                                                                                        // 25
      selector.time.$lt = oldestMsg;                                                                                // 26
    }                                                                                                               // 27
                                                                                                                    //
    if (isPublic) {                                                                                                 // 29
      selector.receiver = targetId;                                                                                 // 30
    } else {                                                                                                        // 31
      selector.sender = selector.receiver = {                                                                       // 32
        $in: [this.userId, targetId]                                                                                // 33
      };                                                                                                            // 32
    }                                                                                                               // 35
                                                                                                                    //
    // build return object                                                                                          //
    var returnObj = {};                                                                                             // 38
                                                                                                                    //
    // if sub for first time                                                                                        //
    if (isNew || oldestMsg >= lastRead) {                                                                           // 41
      var cursor = App.Collections.Message.find(selector, { sort: { time: -1 } });                                  // 42
      // maximun return 100                                                                                         //
      if (cursor.count() > 100) {                                                                                   // 44
        returnObj.leftNew = 100;                                                                                    // 45
        cursor = App.Collections.Message.find(selector, { sort: { time: -1 }, limit: 100 });                        // 46
        returnObj.history = cursor.fetch();                                                                         // 47
      } else {                                                                                                      // 49
        returnObj.leftNew = cursor.count();                                                                         // 50
        returnObj.history = cursor.fetch();                                                                         // 51
        if (returnObj.leftNew) returnObj.history[returnObj.leftNew - 1].startNew = true;                            // 52
                                                                                                                    //
        delete selector.time.$lte;                                                                                  // 55
        delete selector.time.$gt;                                                                                   // 56
        selector.time.$lte = lastRead;                                                                              // 57
        var olderMsg = App.Collections.Message.find(selector, { sort: { time: -1 }, limit: 25 }).fetch();           // 58
        returnObj.history = returnObj.history.concat(olderMsg);                                                     // 59
      }                                                                                                             // 60
    } else {                                                                                                        // 62
      returnObj.history = App.Collections.Message.find(selector, { sort: { time: -1 }, limit: 25 }).fetch();        // 63
    }                                                                                                               // 64
                                                                                                                    //
    return returnObj;                                                                                               // 66
  },                                                                                                                // 67
                                                                                                                    //
  "chats/getLastestMsg": function chatsGetLastestMsg(tags, friends) {                                               // 69
    var _this = this;                                                                                               // 69
                                                                                                                    //
    if (this.isSimulation) return;                                                                                  // 70
                                                                                                                    //
    var lastestMsg = {};                                                                                            // 72
    tags.forEach(function (tagId) {                                                                                 // 73
      var msg = App.Collections.Message.findOne({                                                                   // 74
        is_public: true,                                                                                            // 75
        receiver: tagId                                                                                             // 76
      }, { sort: { time: -1 } });                                                                                   // 74
                                                                                                                    //
      if (msg) lastestMsg[tagId] = msg;                                                                             // 79
    });                                                                                                             // 80
    friends.forEach(function (userId) {                                                                             // 81
      var msg = App.Collections.Message.findOne({                                                                   // 82
        is_public: false,                                                                                           // 83
        sender: { $in: [_this.userId, userId] },                                                                    // 84
        receiver: { $in: [_this.userId, userId] }                                                                   // 85
      }, { sort: { time: -1 } });                                                                                   // 82
                                                                                                                    //
      if (msg) lastestMsg[userId] = msg;                                                                            // 88
    });                                                                                                             // 89
                                                                                                                    //
    return lastestMsg;                                                                                              // 91
  }                                                                                                                 // 92
});                                                                                                                 // 1
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"friends.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// common/methods/friends.js                                                                                        //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
// add friends, delete friends and update friends info                                                              //
                                                                                                                    //
Meteor.methods({                                                                                                    // 4
                                                                                                                    //
  "friends/addStranger": function friendsAddStranger(userId, friendId) {                                            // 6
    if (this.isSimulation) return;                                                                                  // 7
    var friend = Meteor.users.findOne(friendId);                                                                    // 8
    if (!friend) {                                                                                                  // 9
      throw new Meteor.Error("User Not Exists");                                                                    // 10
      return;                                                                                                       // 11
    }                                                                                                               // 12
    var otherStrangers = friend.profile.strangers;                                                                  // 13
                                                                                                                    //
    if (!otherStrangers) {                                                                                          // 15
      otherStrangers = [{ userId: this.userId, validThru: moment().add(7, "days").toDate() }];                      // 16
    } else {                                                                                                        // 17
      otherStrangers.push({ userId: this.userId, validThru: moment().add(7, "days").toDate() });                    // 18
    }                                                                                                               // 19
                                                                                                                    //
    var user = Meteor.user();                                                                                       // 21
    var myStrangers = user.profile.strangers;                                                                       // 22
    if (!myStrangers) {                                                                                             // 23
      myStrangers = [{ userId: friendId, validThru: moment().add(7, "days").toDate() }];                            // 24
    } else {                                                                                                        // 25
      myStrangers.push({ userId: friendId, validThru: moment().add(7, "days").toDate() });                          // 26
    }                                                                                                               // 27
                                                                                                                    //
    Meteor.users.update(this.userId, {                                                                              // 29
      $set: {                                                                                                       // 30
        "profile.strangers": myStrangers                                                                            // 31
      }                                                                                                             // 30
    });                                                                                                             // 29
    Meteor.users.update(friendId, {                                                                                 // 34
      $set: {                                                                                                       // 35
        "profile.strangers": otherStrangers                                                                         // 36
      }                                                                                                             // 35
    });                                                                                                             // 34
  },                                                                                                                // 40
                                                                                                                    //
  // Remove friend from firend list                                                                                 //
  "friends/deleteFriend": function friendsDeleteFriend(friendId) {                                                  // 43
    var _this = this;                                                                                               // 43
                                                                                                                    //
    if (this.isSimulation) return;                                                                                  // 44
                                                                                                                    //
    var friend = Meteor.users.findOne(friendId);                                                                    // 46
    if (!friend) {                                                                                                  // 47
      throw new Meteor.Error("User Not Exists");                                                                    // 48
      return;                                                                                                       // 49
    }                                                                                                               // 50
    var otherTurndown = friend.profile.turndownFriends;                                                             // 51
    if (otherTurndown) {                                                                                            // 52
      otherTurndown.push({ userId: this.userId, validThru: moment().add(7, "days").toDate() });                     // 53
    } else {                                                                                                        // 54
      otherTurndown = [{ userId: this.userId, validThru: moment().add(7, "days").toDate() }];                       // 55
    }                                                                                                               // 56
    var otherFriends = friend.profile.friends;                                                                      // 57
    if (otherFriends) otherFriends = otherFriends.filter(function (user) {                                          // 58
      return user.userId != _this.userId;                                                                           // 59
    });                                                                                                             // 59
                                                                                                                    //
    var user = Meteor.user();                                                                                       // 61
    var myTurndown = user.profile.turndownFriends;                                                                  // 62
    if (myTurndown) {                                                                                               // 63
      myTurndown.push({ userId: friendId, validThru: moment().add(7, "days").toDate() });                           // 64
    } else {                                                                                                        // 65
      myTurndown = [{ userId: friendId, validThru: moment().add(7, "days").toDate() }];                             // 66
    }                                                                                                               // 67
    var myFriends = user.profile.friends;                                                                           // 68
    if (myFriends) myFriends = myFriends.filter(function (user) {                                                   // 69
      return user.userId != friendId;                                                                               // 70
    });                                                                                                             // 70
                                                                                                                    //
    Meteor.users.update(this.userId, {                                                                              // 72
      $set: {                                                                                                       // 73
        "profile.turndownFriends": myTurndown,                                                                      // 74
        "profile.friends": myFriends                                                                                // 75
      }                                                                                                             // 73
    });                                                                                                             // 72
    Meteor.users.update(friendId, {                                                                                 // 78
      $set: {                                                                                                       // 79
        "profile.turndownFriends": otherTurndown,                                                                   // 80
        "profile.friends": otherFriends                                                                             // 81
      }                                                                                                             // 79
    });                                                                                                             // 78
  },                                                                                                                // 84
                                                                                                                    //
  'friends/sendRequest': function friendsSendRequest(friendId) {                                                    // 86
    var _this2 = this;                                                                                              // 86
                                                                                                                    //
    // check block                                                                                                  //
    var friend = Meteor.users.findOne(friendId);                                                                    // 88
    if (!friend) {                                                                                                  // 89
      throw new Meteor.Error("User Not Exists");                                                                    // 90
      return;                                                                                                       // 91
    }                                                                                                               // 92
    var otherTurndown = friend.profile.turndownFriends;                                                             // 93
    if (otherTurndown && otherTurndown.find(function (user) {                                                       // 94
      return user.userId == _this2.userId;                                                                          // 94
    })) {                                                                                                           // 94
      throw new Meteor.Error("You are Blocked");                                                                    // 95
      return;                                                                                                       // 96
    }                                                                                                               // 97
    var otherRequest = friend.profile.friendRequest;                                                                // 98
    if (!otherRequest) {                                                                                            // 99
      otherRequest = [{ userId: this.userId }];                                                                     // 100
    } else if (!otherRequest.find(function (user) {                                                                 // 101
      return user.userId == _this2.userId;                                                                          // 101
    })) {                                                                                                           // 101
      otherRequest.push({ userId: this.userId });                                                                   // 102
    }                                                                                                               // 103
                                                                                                                    //
    var otherRecommend = friend.profile.recommendedFriends;                                                         // 105
    if (otherRecommend) otherRecommend = otherRecommend.filter(function (user) {                                    // 106
      return user.userId != _this2.userId;                                                                          // 107
    });                                                                                                             // 107
                                                                                                                    //
    var myRecommend = Meteor.user().profile.recommendedFriends;                                                     // 109
    if (myRecommend) myRecommend = myRecommend.filter(function (user) {                                             // 110
      return user.userId != friendId;                                                                               // 111
    });                                                                                                             // 111
                                                                                                                    //
    Meteor.users.update(this.userId, {                                                                              // 113
      $set: {                                                                                                       // 114
        "profile.recommendedFriends": myRecommend                                                                   // 115
      }                                                                                                             // 114
    });                                                                                                             // 113
    Meteor.users.update(friendId, {                                                                                 // 118
      $set: {                                                                                                       // 119
        "profile.friendRequest": otherRequest,                                                                      // 120
        "profile.recommendedFriends": otherRecommend                                                                // 121
      }                                                                                                             // 119
    });                                                                                                             // 118
  },                                                                                                                // 124
                                                                                                                    //
  "friends/ignoreRecommendation": function friendsIgnoreRecommendation(friendId) {                                  // 126
    if (this.isSimulation) return;                                                                                  // 127
                                                                                                                    //
    var recommend = Meteor.user().profile.recommendedFriends;                                                       // 129
    if (recommend) recommend = recommend.filter(function (user) {                                                   // 130
      return user.userId != friendId;                                                                               // 131
    });                                                                                                             // 131
    Meteor.users.update(this.userId, {                                                                              // 132
      $set: {                                                                                                       // 133
        "profile.recommendedFriends": recommend                                                                     // 134
      }                                                                                                             // 133
    });                                                                                                             // 132
                                                                                                                    //
    return;                                                                                                         // 138
  },                                                                                                                // 139
                                                                                                                    //
  // Add  friend id to each person's db                                                                             //
  "friends/addFriend": function friendsAddFriend(friendId) {                                                        // 142
    var _this3 = this;                                                                                              // 142
                                                                                                                    //
    if (this.isSimulation) return;                                                                                  // 143
                                                                                                                    //
    console.log(friendId);                                                                                          // 145
    var user = Meteor.user();                                                                                       // 146
    var myFriends = user.profile.friends;                                                                           // 147
    var friendRecommend = user.profile.recommendedFriends;                                                          // 148
    var friendRequest = user.profile.friendRequest;                                                                 // 149
    var strangers = user.profile.strangers;                                                                         // 150
    if (friendRequest) friendRequest = friendRequest.filter(function (user) {                                       // 151
      return user.userId != friendId;                                                                               // 152
    });                                                                                                             // 152
    if (strangers) strangers = strangers.filter(function (user) {                                                   // 153
      return user.userId != friendId;                                                                               // 154
    });                                                                                                             // 154
    if (friendRecommend) friendRecommend = friendRecommend.filter(function (user) {                                 // 155
      return user.userId != friendId;                                                                               // 156
    });                                                                                                             // 156
    Meteor.users.update(this.userId, {                                                                              // 157
      $set: {                                                                                                       // 158
        "profile.friendRequest": friendRequest,                                                                     // 159
        "profile.strangers": strangers,                                                                             // 160
        "profile.friendRecommend": friendRecommend                                                                  // 161
      }                                                                                                             // 158
    });                                                                                                             // 157
                                                                                                                    //
    var friend = Meteor.users.findOne(friendId);                                                                    // 165
    if (!friend) {                                                                                                  // 166
      throw new Meteor.Error("User Not Existed");                                                                   // 167
      return;                                                                                                       // 168
    }                                                                                                               // 169
                                                                                                                    //
    if (!myFriends) {                                                                                               // 171
      myFriends = [{ userId: friendId }];                                                                           // 172
    } else {                                                                                                        // 173
      myFriends.push({ userId: friendId });                                                                         // 174
    }                                                                                                               // 175
                                                                                                                    //
    var otherRequest = friend.profile.friendRequest;                                                                // 177
    var otherStrangers = friend.profile.strangers;                                                                  // 178
    var otherRecommends = friend.profile.recommendedFriends;                                                        // 179
    if (otherRequest) otherRequest = otherRequest.filter(function (user) {                                          // 180
      return user.userId != _this3.userId;                                                                          // 181
    });                                                                                                             // 181
    if (otherStrangers) otherStrangers = otherStrangers.filter(function (user) {                                    // 182
      return user.userId != _this3.userId;                                                                          // 183
    });                                                                                                             // 183
    if (otherRecommends) otherRecommends = otherRecommends.filter(function (user) {                                 // 184
      return user.userId != _this3.userId;                                                                          // 185
    });                                                                                                             // 185
    var otherFriends = friend.profile.friends;                                                                      // 186
    if (!otherFriends) {                                                                                            // 187
      otherFriends = [{ userId: this.userId }];                                                                     // 188
    } else {                                                                                                        // 189
      otherFriends.push({ userId: this.userId });                                                                   // 190
    }                                                                                                               // 191
                                                                                                                    //
    Meteor.users.update(this.userId, { $set: { "profile.friends": myFriends } });                                   // 193
    Meteor.users.update(friendId, {                                                                                 // 194
      $set: {                                                                                                       // 195
        "profile.friends": otherFriends,                                                                            // 196
        "profile.friendRequest": otherRequest,                                                                      // 197
        "profile.strangers": otherStrangers,                                                                        // 198
        "profile.recommendedFriends": otherRecommends                                                               // 199
      }                                                                                                             // 195
    });                                                                                                             // 194
                                                                                                                    //
    return true;                                                                                                    // 203
  },                                                                                                                // 204
                                                                                                                    //
  "friends/dismissFriend": function friendsDismissFriend(friendId) {                                                // 206
    var _this4 = this;                                                                                              // 206
                                                                                                                    //
    if (this.isSimulation) return;                                                                                  // 207
                                                                                                                    //
    var user = Meteor.user();                                                                                       // 209
    var friendRecommend = user.profile.recommendedFriends;                                                          // 210
    var friendRequest = user.profile.friendRequest;                                                                 // 211
    var turndownFriends = user.profile.turndownFriends;                                                             // 212
    if (friendRequest) friendRequest = friendRequest.filter(function (user) {                                       // 213
      return user.userId != friendId;                                                                               // 214
    });                                                                                                             // 214
    if (friendRecommend) friendRecommend = friendRecommend.filter(function (user) {                                 // 215
      return user.userId != friendId;                                                                               // 216
    });                                                                                                             // 216
    if (turndownFriends) {                                                                                          // 217
      turndownFriends.push({ userId: friendId, validThru: moment().add(7, "days").toDate() });                      // 218
    } else {                                                                                                        // 219
      turndownFriends = [{ userId: friendId, validThru: moment().add(7, "days").toDate() }];                        // 220
    }                                                                                                               // 221
    Meteor.users.update(this.userId, {                                                                              // 222
      $set: {                                                                                                       // 223
        "profile.friendRequest": friendRequest,                                                                     // 224
        "profile.turndownFriends": turndownFriends,                                                                 // 225
        "profile.friendRecommend": friendRecommend                                                                  // 226
      }                                                                                                             // 223
    });                                                                                                             // 222
                                                                                                                    //
    var friend = Meteor.users.findOne(friendId);                                                                    // 230
    if (!friend) {                                                                                                  // 231
      throw new Meteor.Error("User Not Existed");                                                                   // 232
      return;                                                                                                       // 233
    }                                                                                                               // 234
    var otherRecommend = friend.profile.recommendedFriends;                                                         // 235
    var otherRequest = friend.profile.friendRequest;                                                                // 236
    var otherTurndown = friend.profile.turndownFriends;                                                             // 237
    if (otherRequest) otherRequest = otherRequest.filter(function (user) {                                          // 238
      return user.userId != _this4.userId;                                                                          // 239
    });                                                                                                             // 239
    if (otherRecommend) otherRecommend = otherRecommend.filter(function (user) {                                    // 240
      return user.userId != _this4.userId;                                                                          // 241
    });                                                                                                             // 241
                                                                                                                    //
    if (otherTurndown) {                                                                                            // 243
      otherTurndown.push({ userId: this.userId, validThru: moment().add(7, "days").toDate() });                     // 244
    } else {                                                                                                        // 245
      otherTurndown = [{ userId: this.userId, validThru: moment().add(7, "days").toDate() }];                       // 246
    }                                                                                                               // 247
                                                                                                                    //
    Meteor.users.update(friendId, {                                                                                 // 249
      $set: {                                                                                                       // 250
        "profile.friendRequest": otherRequest,                                                                      // 251
        "profile.turndownFriends": otherTurndown,                                                                   // 252
        "profile.recommendedFriends": otherRecommend                                                                // 253
      }                                                                                                             // 250
    });                                                                                                             // 249
                                                                                                                    //
    return true;                                                                                                    // 257
  },                                                                                                                // 258
                                                                                                                    //
  // call this function if and only if user 1 and user 2 are already friends                                        //
  // Not implement this prerequisite yet                                                                            //
  "friends/editNickname": function friendsEditNickname(friendId, name) {                                            // 262
    if (this.isSimulation) return;                                                                                  // 263
                                                                                                                    //
    // check whether there are friends                                                                              //
    var index = 0;                                                                                                  // 266
    var friendList = Meteor.user().profile.friends;                                                                 // 267
    for (index = 0; index < friendList.length; index++) {                                                           // 268
      if (friendList[index].userId == friendId) {                                                                   // 269
        friendList[index].nickname = name;                                                                          // 270
        break;                                                                                                      // 271
      }                                                                                                             // 272
    }                                                                                                               // 273
                                                                                                                    //
    if (index < friendList.length) {                                                                                // 275
      Meteor.users.update(this.userId, { $set: { "profile.friends": friendList } });                                // 276
    } else {                                                                                                        // 277
      throw new Meteor.Error("Not Friend");                                                                         // 278
      return;                                                                                                       // 279
    }                                                                                                               // 280
  }                                                                                                                 // 281
});                                                                                                                 // 4
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"tags.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// common/methods/tags.js                                                                                           //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
Meteor.methods({                                                                                                    // 1
  'tags/createTag': function tagsCreateTag(tagData, wifiArray) {                                                    // 2
    // research isSimulation                                                                                        //
    if (this.isSimulation) return;                                                                                  // 4
                                                                                                                    //
    var doc = App.Collections.Tags.findOne({ name: tagData.name });                                                 // 6
    if (doc && doc.name) {                                                                                          // 7
      console.log("Tag Name already exists");                                                                       // 8
      throw new Meteor.Error("Error in creating", "Tag Name already exists");                                       // 9
    }                                                                                                               // 10
                                                                                                                    //
    var tagId = App.Collections.Tags.insert(tagData);                                                               // 12
                                                                                                                    //
    wifiArray.forEach(function (wifi) {                                                                             // 14
      var wifiInDb = App.Collections.Wifis.findOne({ bssid: wifi.bssid });                                          // 15
      if (wifiInDb) {                                                                                               // 16
        wifi.id = wifiInDb._id;                                                                                     // 17
        App.Collections.Wifis.update(wifi.id, { "$push": { "tags": tagId } });                                      // 18
      } else {                                                                                                      // 19
        wifi.id = App.Collections.Wifis.insert({                                                                    // 20
          bssid: wifi.bssid,                                                                                        // 21
          ssid: wifi.ssid,                                                                                          // 22
          tags: [tagId]                                                                                             // 23
        });                                                                                                         // 20
      }                                                                                                             // 25
    });                                                                                                             // 26
                                                                                                                    //
    var wifiInTag = wifiArray.map(function (wifi) {                                                                 // 28
      return {                                                                                                      // 29
        wifiId: wifi.bssid,                                                                                         // 30
        level: wifi.level                                                                                           // 31
      };                                                                                                            // 29
    });                                                                                                             // 33
    App.Collections.Tags.update(tagId, { $set: { wifis: wifiInTag } });                                             // 34
    return tagId;                                                                                                   // 35
  },                                                                                                                // 36
                                                                                                                    //
  "tags/getTagsById": function tagsGetTagsById(tagIds) {                                                            // 38
    return App.Collections.Tags.find({ _id: { $in: tagIds } }).fetch();                                             // 39
  },                                                                                                                // 40
                                                                                                                    //
  "tags/addActiveUser": function tagsAddActiveUser(tagId) {                                                         // 42
    if (this.isSimulation) return;                                                                                  // 43
    var tag = App.Collections.Tags.findOne(tagId);                                                                  // 44
    if (!tag) return;                                                                                               // 45
    var activeUser = tag.activeUser ? tag.activeUser.concat([this.userId]) : [this.userId];                         // 46
    App.Collections.Tags.update(tagId, {                                                                            // 47
      "$set": {                                                                                                     // 48
        "activeUser": activeUser                                                                                    // 49
      }                                                                                                             // 48
    });                                                                                                             // 47
  },                                                                                                                // 52
                                                                                                                    //
  "tags/subscribe": function tagsSubscribe(tagId) {                                                                 // 54
    var _this = this;                                                                                               // 54
                                                                                                                    //
    if (this.isSimulation) return;                                                                                  // 55
    var tag = App.Collections.Tags.findOne(tagId);                                                                  // 56
    var users = tag.users ? tag.users.concat([this.userId]) : [this.userId];                                        // 57
    var activeUser = tag.activeUser ? tag.activeUser.filter(function (id) {                                         // 58
      return id != _this.userId;                                                                                    // 58
    }) : [];                                                                                                        // 58
                                                                                                                    //
    App.Collections.Tags.update(tagId, {                                                                            // 60
      "$set": {                                                                                                     // 61
        "users": users,                                                                                             // 62
        "activeUser": activeUser                                                                                    // 63
      }                                                                                                             // 61
    });                                                                                                             // 60
                                                                                                                    //
    var savedTag = {                                                                                                // 67
      tagId: tagId,                                                                                                 // 68
      validThru: moment().add(7, "days").toDate(),                                                                  // 69
      calendar: false                                                                                               // 70
    };                                                                                                              // 67
    Meteor.users.update(this.userId, {                                                                              // 72
      "$push": {                                                                                                    // 73
        "profile.savedTags": savedTag                                                                               // 74
      }                                                                                                             // 73
    });                                                                                                             // 72
  },                                                                                                                // 77
                                                                                                                    //
  "tags/unsubscribe": function tagsUnsubscribe(tagId) {                                                             // 79
    var _this2 = this;                                                                                              // 79
                                                                                                                    //
    if (this.isSimulation) return;                                                                                  // 80
    var tag = App.Collections.Tags.findOne(tagId);                                                                  // 81
    var users = tag.users ? tag.users.filter(function (id) {                                                        // 82
      return id != _this2.userId;                                                                                   // 82
    }) : [];                                                                                                        // 82
    var activeUser = tag.activeUser ? tag.activeUser.concat([this.userId]) : [this.userId];                         // 83
                                                                                                                    //
    App.Collections.Tags.update(tagId, {                                                                            // 85
      "$set": {                                                                                                     // 86
        "users": users,                                                                                             // 87
        "activeUser": activeUser                                                                                    // 88
      }                                                                                                             // 86
    });                                                                                                             // 85
                                                                                                                    //
    var savedTags = Meteor.user().profile.savedTags.filter(function (tag) {                                         // 92
      return tag.tagId != tagId;                                                                                    // 92
    });                                                                                                             // 92
    Meteor.users.update(this.userId, {                                                                              // 93
      "$set": {                                                                                                     // 94
        "profile.savedTags": savedTags                                                                              // 95
      }                                                                                                             // 94
    });                                                                                                             // 93
  }                                                                                                                 // 98
});                                                                                                                 // 1
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"users.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// common/methods/users.js                                                                                          //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
Meteor.methods({                                                                                                    // 1
  'user/rollProfilePicture': function userRollProfilePicture() {                                                    // 2
    // research isSimulation                                                                                        //
    if (this.isSimulation) return;                                                                                  // 4
                                                                                                                    //
    // only server runs the code                                                                                    //
    var profileSeed = Random.id(8);                                                                                 // 7
    console.log("New Seed " + profileSeed);                                                                         // 8
    return Meteor.users.update({ "_id": this.userId }, { $set: { "profile.profileSeed": profileSeed } });           // 9
  },                                                                                                                // 11
                                                                                                                    //
  'user/rollChatroomPicture': function userRollChatroomPicture() {                                                  // 13
    // research isSimulation                                                                                        //
    if (this.isSimulation) return;                                                                                  // 15
                                                                                                                    //
    // only server runs the code                                                                                    //
    var chatroomSeed = Random.id(7);                                                                                // 18
    console.log("New Seed " + chatroomSeed);                                                                        // 19
    return Meteor.users.update({ "_id": this.userId }, { $set: { "chat.chatroomSeed": chatroomSeed } });            // 20
  },                                                                                                                // 22
                                                                                                                    //
  'user/changeEmail': function userChangeEmail(newEmail) {                                                          // 24
    if (this.isSimulation) return;                                                                                  // 25
                                                                                                                    //
    if (Accounts.findUserByEmail(newEmail)) {                                                                       // 27
      throw new Meteor.Error("Email Exists");                                                                       // 28
      return;                                                                                                       // 29
    }                                                                                                               // 30
    return Meteor.users.update({ "_id": this.userId }, { $set: { "emails.0.address": newEmail } });                 // 31
  },                                                                                                                // 33
                                                                                                                    //
  'user/changeFacebook': function userChangeFacebook(newFacebook) {                                                 // 35
    if (this.isSimulation) return;                                                                                  // 36
    console.log("new facebook account to be edited: " + newFacebook);                                               // 37
    if (!Meteor.user().profile.socialMedia) {                                                                       // 38
      console.log("No socialMedia created before");                                                                 // 39
      return Meteor.users.update({ _id: this.userId }, { $set: { "profile.socialMedia": { 'facebook': newFacebook } } }, false, true);
    } else {                                                                                                        // 41
      console.log("socialMedia already exist");                                                                     // 43
      return Meteor.users.update({ _id: this.userId }, { $set: { "profile.socialMedia.facebook": newFacebook } });  // 44
    }                                                                                                               // 45
  },                                                                                                                // 46
                                                                                                                    //
  'user/changeGithub': function userChangeGithub(newGithub) {                                                       // 48
    if (this.isSimulation) return;                                                                                  // 49
    console.log("new github account to be edited: " + newGithub);                                                   // 50
    if (!Meteor.user().profile.socialMedia) {                                                                       // 51
      console.log("No socialMedia created before");                                                                 // 52
      return Meteor.users.update({ _id: this.userId }, { $set: { "profile.socialMedia": { 'github': newGithub } } }, false, true);
    } else {                                                                                                        // 54
      console.log("socialMedia already exist");                                                                     // 56
      return Meteor.users.update({ _id: this.userId }, { $set: { "profile.socialMedia.github": newGithub } });      // 57
    }                                                                                                               // 58
  },                                                                                                                // 59
                                                                                                                    //
  'user/changeAllowRecommend': function userChangeAllowRecommend() {                                                // 61
    if (this.isSimulation) return;                                                                                  // 62
    console.log("change allow to be recommended option");                                                           // 63
    if (Meteor.user().allowBeRecommended) {                                                                         // 64
      console.log("Do not allow");                                                                                  // 65
      return Meteor.users.update({ _id: this.userId }, { $set: { "allowBeRecommended": false } });                  // 66
    } else {                                                                                                        // 67
      console.log("Allow");                                                                                         // 69
      return Meteor.users.update({ _id: this.userId }, { $set: { "allowBeRecommended": true } });                   // 70
    }                                                                                                               // 71
  },                                                                                                                // 72
                                                                                                                    //
  'user/changeUserName': function userChangeUserName(newUserName) {                                                 // 74
    if (this.isSimulation) return;                                                                                  // 75
    console.log(newUserName);                                                                                       // 76
                                                                                                                    //
    if (Accounts.findUserByUsername(newUserName)) {                                                                 // 78
      throw new Meteor.Error("Sorry, this username already exists.");                                               // 79
      return false;                                                                                                 // 80
    } else {                                                                                                        // 81
      console.log("Successfully changed username!");                                                                // 83
      return Meteor.users.update({ "_id": this.userId }, { $set: { "username": newUserName } });                    // 84
    }                                                                                                               // 86
  },                                                                                                                // 87
                                                                                                                    //
  'user/checkUsername': function userCheckUsername(newUsername) {                                                   // 89
    if (this.isSimulation) return;                                                                                  // 90
                                                                                                                    //
    if (Accounts.findUserByUsername(newUsername)) {                                                                 // 92
      throw new Meteor.Error("Unsername Exists");                                                                   // 93
      return false;                                                                                                 // 94
    }                                                                                                               // 95
  },                                                                                                                // 96
                                                                                                                    //
  'user/checkEmail': function userCheckEmail(newEmail) {                                                            // 98
    if (this.isSimulation) return;                                                                                  // 99
                                                                                                                    //
    if (Accounts.findUserByEmail(newEmail)) {                                                                       // 101
      throw new Meteor.Error("Unsername Exists");                                                                   // 102
      return false;                                                                                                 // 103
    }                                                                                                               // 104
  },                                                                                                                // 105
                                                                                                                    //
  'user/updateToken': function userUpdateToken(newToken) {                                                          // 107
    if (this.isSimulation) return;                                                                                  // 108
                                                                                                                    //
    return Meteor.users.update({ "_id": this.userId }, { $set: { "token": newToken } });                            // 110
  }                                                                                                                 // 112
                                                                                                                    //
});                                                                                                                 // 1
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"services":{"notification.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// common/services/notification.js                                                                                  //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
if (Meteor.isServer) {                                                                                              // 1
  App.Services.Notification = {                                                                                     // 2
    sendGCMNotification: function sendGCMNotification(msg) {                                                        // 3
      msg.time = msg.time.toISOString();                                                                            // 4
      var gcmNotification = {                                                                                       // 5
        priority: "high",                                                                                           // 6
        notification: {                                                                                             // 7
          body: msg.message                                                                                         // 8
        },                                                                                                          // 7
        data: msg                                                                                                   // 10
      };                                                                                                            // 5
                                                                                                                    //
      // add receiver                                                                                               //
      if (msg.is_public) {                                                                                          // 14
        gcmNotification.to = msg.receiver;                                                                          // 15
        var title = App.Collections.Tags.findOne(msg.receiver).name;                                                // 16
      } else {                                                                                                      // 17
        var user = Meteor.users.findOne(msg.receiver);                                                              // 18
        if (!user.token) return false;                                                                              // 19
                                                                                                                    //
        gcmNotification.to = user.token;                                                                            // 21
        gcmNotification.notification.title = user.username;                                                         // 22
      }                                                                                                             // 23
                                                                                                                    //
      HTTP.call("POST", "https://fcm.googleapis.com/fcm/send", {                                                    // 25
        data: gcmNotification,                                                                                      // 26
        headers: {                                                                                                  // 27
          'Content-Type': 'application/json',                                                                       // 28
          "Authorization": "key=AIzaSyCNk41CknnmKqUrY41CkKz-jH-AQvbVB6E"                                            // 29
        }                                                                                                           // 27
      }, function (err, res) {                                                                                      // 25
        if (err) console.log("GCM error");else console.log("GCM success");                                          // 32
      });                                                                                                           // 36
    }                                                                                                               // 37
  };                                                                                                                // 2
}                                                                                                                   // 39
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"accounts":{"accounts_config.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/accounts/accounts_config.js                                                                               //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
/**                                                                                                                 //
 * Meteor Accounts Settings,                                                                                        //
 * define what to do when new user created, How to send reset password email                                        //
 */                                                                                                                 //
                                                                                                                    //
Accounts.config({                                                                                                   // 6
  loginExpirationInDays: 90,                                                                                        // 7
  sendVerificationEmail: false,                                                                                     // 8
  forbidClientAccountCreation: false                                                                                // 9
});                                                                                                                 // 6
                                                                                                                    //
/**                                                                                                                 //
 * Initialize student User account with basic data on first login                                                   //
 */                                                                                                                 //
Accounts.onCreateUser(function (options, user) {                                                                    // 15
  // make friends                                                                                                   //
  if (["Ensign", "Lieutenant", "Commander", "Captain", "Admiral", "JohnD", "JaneD"].indexOf(user.username) == -1) {
    var ensign = Accounts.findUserByUsername("Ensign")._id;                                                         // 18
    var lieutenant = Accounts.findUserByUsername("Lieutenant")._id;                                                 // 19
    var commander = Accounts.findUserByUsername("Commander")._id;                                                   // 20
    var captain = Accounts.findUserByUsername("Captain")._id;                                                       // 21
    var admiral = Accounts.findUserByUsername("Admiral")._id;                                                       // 22
    var john = Accounts.findUserByUsername("JohnD")._id;                                                            // 23
    var jane = Accounts.findUserByUsername("JaneD")._id;                                                            // 24
                                                                                                                    //
    Meteor.users.update({ username: { $in: ["Ensign", "Lieutenant", "Commander", "Captain", "Admiral"] } }, { $push: { "profile.friends": { userId: user._id } } });
                                                                                                                    //
    user.profile = {                                                                                                // 28
      profileSeed: Random.id(8),                                                                                    // 29
      friendRequest: [{ userId: john, requestReason: "You have this request by default" }],                         // 30
      recommendedFriends: [{ userId: jane, recommendReason: "You have this recommendation by default" }],           // 31
      turndownFriends: [],                                                                                          // 32
      friends: [{ userId: ensign }, { userId: lieutenant }, { userId: commander }, { userId: captain }, { userId: admiral }],
      Strangers: []                                                                                                 // 34
    };                                                                                                              // 28
  } else {                                                                                                          // 36
    user.profile = {                                                                                                // 37
      profileSeed: Random.id(8),                                                                                    // 38
      friendRequest: [],                                                                                            // 39
      recommendedFriends: [],                                                                                       // 40
      turndownFriends: [],                                                                                          // 41
      friends: [],                                                                                                  // 42
      Strangers: []                                                                                                 // 43
    };                                                                                                              // 37
  }                                                                                                                 // 45
                                                                                                                    //
  var earth = App.Collections.Tags.findOne({ name: "Earth" })._id;                                                  // 47
  var mars = App.Collections.Tags.findOne({ name: "Mars" })._id;                                                    // 48
  var moon = App.Collections.Tags.findOne({ name: "Moon" })._id;                                                    // 49
  user.profile.savedTags = [{ tagId: earth, validThru: new Date(2018, 1, 1) }, { tagId: mars, validThru: new Date(2018, 1, 1) }, { tagId: moon, validThru: new Date(2018, 1, 1) }];
  user.allowBeRecommended = true;                                                                                   // 51
                                                                                                                    //
  // subscribe tags                                                                                                 //
  App.Collections.Tags.update({ name: "Earth" }, { $push: { "users": user._id } });                                 // 54
  App.Collections.Tags.update({ name: "Moon" }, { $push: { "users": user._id } });                                  // 55
  App.Collections.Tags.update({ name: "Mars" }, { $push: { "users": user._id } });                                  // 56
                                                                                                                    //
  return user;                                                                                                      // 58
});                                                                                                                 // 59
                                                                                                                    //
/**                                                                                                                 //
 * Set reset password email template, initialized when server startup                                               //
 */                                                                                                                 //
App.Initializer.configureResetEmail = function () {                                                                 // 64
  Accounts.emailTemplates.siteName = "Submarine";                                                                   // 65
  Accounts.emailTemplates.from = "noreply.submarine.cse110@gmail.com";                                              // 66
  Accounts.emailTemplates.resetPassword.subject = function (user) {                                                 // 67
    return "Reset your password on Submarine";                                                                      // 67
  };                                                                                                                // 67
                                                                                                                    //
  Accounts.emailTemplates.resetPassword.text = function (user, url) {                                               // 70
    return "Copy the token to specified field to reset your password: \r\n\n\n" + url;                              // 70
  };                                                                                                                // 70
                                                                                                                    //
  Accounts.emailTemplates.resetPassword.html = function (user, url) {                                               // 73
    return "<p>Copy the token to specified field to reset your password:</p><p>" + url + "</p>";                    // 73
  };                                                                                                                // 73
                                                                                                                    //
  Accounts.urls.resetPassword = function (token) {                                                                  // 76
    return token;                                                                                                   // 76
  };                                                                                                                // 76
};                                                                                                                  // 77
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"mail":{"init_mail.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/mail/init_mail.js                                                                                         //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
/**                                                                                                                 //
 * Initialize external smtp setting, sending site email                                                             //
 */                                                                                                                 //
App.Initializer.SMTP = function () {                                                                                // 4
                                                                                                                    //
  var settings = App.Collections.Settings.findOne();                                                                // 6
  process.env.MAIL_URL = 'smtp://' + encodeURIComponent(settings.smtpUsername) + ':' + encodeURIComponent(settings.smtpPassword) + '@' + encodeURIComponent(settings.smtpAddress) + ':' + settings.smtpPort;
};                                                                                                                  // 11
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"publications":{"chat.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/publications/chat.js                                                                                      //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
Meteor.publish("chat/friendChats", function (friendId) {                                                            // 1
                                                                                                                    //
  var selector = {                                                                                                  // 3
    is_public: false,                                                                                               // 4
    sender: { $in: [this.userId, friendId] },                                                                       // 5
    receiver: { $in: [this.userId, friendId] },                                                                     // 6
    time: {                                                                                                         // 7
      $gte: new Date()                                                                                              // 8
    }                                                                                                               // 7
  };                                                                                                                // 3
                                                                                                                    //
  return App.Collections.Message.find(selector, { sort: { time: -1 } });                                            // 12
});                                                                                                                 // 13
                                                                                                                    //
Meteor.publish("chat/tagChats", function (tagId) {                                                                  // 15
                                                                                                                    //
  var selector = {                                                                                                  // 17
    is_public: true,                                                                                                // 18
    receiver: tagId,                                                                                                // 19
    time: {                                                                                                         // 20
      $gte: new Date()                                                                                              // 21
    }                                                                                                               // 20
  };                                                                                                                // 17
                                                                                                                    //
  return App.Collections.Message.find(selector, { sort: { time: -1 } });                                            // 25
});                                                                                                                 // 26
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"messages.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/publications/messages.js                                                                                  //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
// publish chat history between users                                                                               //
Meteor.publish("messages/friendHistory", function (friendId, fromDate) {                                            // 2
                                      return App.Collections.Message.find({                                         // 3
                                                                            "is_public": false,                     // 4
                                                                            "time": { "$gte": fromDate },           // 5
                                                                            "sender": { "$in": [this.userId, friendId] },
                                                                            "receiver": { "$in": [this.userId, friendId] }
                                      }, { "limit": 100 });                                                         // 3
});                                                                                                                 // 9
                                                                                                                    //
// publish chat history in chatroom                                                                                 //
Meteor.publish("messages/chatRoomHistory", function (tagId, fromDate) {                                             // 12
                                      return App.Collections.Message.find({                                         // 13
                                                                            "is_public": true,                      // 14
                                                                            "time": { "$gte": fromDate },           // 15
                                                                            "receiver": tagId                       // 16
                                      }, { "limit": 100 });                                                         // 13
});                                                                                                                 // 18
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"tags.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/publications/tags.js                                                                                      //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
// publish tags accociated with wifis                                                                               //
Meteor.publish("tags/tagsUnderWifis", function (wifiList) {                                                         // 2
                                                                                                                    //
  var bssids = wifiList.map(function (wifi) {                                                                       // 4
    return wifi.bssid;                                                                                              // 4
  });                                                                                                               // 4
  var wifiInDB = App.Collections.Wifis.find({ "bssid": { "$in": bssids } }, { "fields": { "tags": 1 } }).fetch();   // 5
                                                                                                                    //
  //console.log(JSON.stringify(wifiInDB, undefined, 2));                                                            //
                                                                                                                    //
  var tagList = [];                                                                                                 // 10
  wifiInDB.forEach(function (wifi) {                                                                                // 11
    if (wifi.tags && wifi.tags.length) tagList = tagList.concat(wifi.tags);                                         // 12
  });                                                                                                               // 14
                                                                                                                    //
  //console.log(JSON.stringify(tagList, undefined, 2));                                                             //
  /*                                                                                                                //
  var tagList = wifiInDB.reduce( function(wifi1, wifi2) {                                                           //
    return (wifi1.tags).concat(wifi2.tags)                                                                          //
  }, {tags:[]} );                                                                                                   //
  */                                                                                                                //
                                                                                                                    //
  return App.Collections.Tags.find({ "_id": { "$in": tagList } }, { "fields": { "users": 0, "activeUser": 0 } });   // 23
});                                                                                                                 // 26
                                                                                                                    //
// publish users under the tag to user, for user profile picture in chat                                            //
Meteor.publish("tags/usersUnderTag", function (tagId) {                                                             // 29
                                                                                                                    //
  var tag = App.Collections.Tags.findOne({ "_id": tagId }, { "fields": { "users": 1, "activeUser": 1 } });          // 31
  if (!tag) return;                                                                                                 // 33
                                                                                                                    //
  var users = tag.users.concat(tag.activeUser);                                                                     // 35
                                                                                                                    //
  return Meteor.users.find({ "_id": { "$in": users } }, { "fields": { "profile.profileSeed": 1 } });                // 37
});                                                                                                                 // 39
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"users.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/publications/users.js                                                                                     //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
// publish user's friends strangers pending request and friend recommendation data                                  //
Meteor.publish("users/relatedUsersAndTags", function () {                                                           // 2
  if (!this.userId) return this.ready();                                                                            // 3
                                                                                                                    //
  //Update this in the collection                                                                                   //
  Meteor.users.update(this.userId, { $set: { "online": true } });                                                   // 7
                                                                                                                    //
  var user = Meteor.users.findOne({ "_id": this.userId }, { "profile.profileSeed": 1,                               // 9
    "profile.friendRequest": 1,                                                                                     // 10
    "profile.recommendedFriends": 1,                                                                                // 11
    "profile.friends": 1,                                                                                           // 12
    "profile.strangers": 1,                                                                                         // 13
    "profile.savedTags": 1,                                                                                         // 14
    "profile.socialMedia": 1                                                                                        // 15
  });                                                                                                               // 9
  // publish user seed and also social media                                                                        //
  var userIds = [].concat(user.profile.profileSeed, user.profile.friendRequest.map(function (requests) {            // 18
    return requests.userId;                                                                                         // 18
  }), user.profile.socialMedia, user.profile.recommendedFriends.map(function (recommendation) {                     // 18
    return recommendation.userId;                                                                                   // 19
  }), user.profile.friends.map(function (friend) {                                                                  // 19
    return friend.userId;                                                                                           // 20
  }));                                                                                                              // 20
                                                                                                                    //
  // publish chat room description and status                                                                       //
  var tagIds = user.profile.savedTags.map(function (tag) {                                                          // 23
    return tag.tagId;                                                                                               // 23
  });                                                                                                               // 23
                                                                                                                    //
  //Detect that the user exit the application                                                                       //
  var self = this;                                                                                                  // 26
  this.onStop(function () {                                                                                         // 27
    Meteor.users.update(self.userId, { "$set": { "online": false } });                                              // 28
  });                                                                                                               // 30
                                                                                                                    //
  return [Meteor.users.find({ "_id": { "$in": userIds } }, {                                                        // 32
    "fields": {                                                                                                     // 35
      "profile.profileSeed": 1,                                                                                     // 36
      "username": 1,                                                                                                // 37
      "emails": 1,                                                                                                  // 38
      "profile.socialMedia": 1,                                                                                     // 39
      "profile.savedTags": 1                                                                                        // 40
    }                                                                                                               // 35
  }), App.Collections.Tags.find({ "_id": { "$in": tagIds } })];                                                     // 34
});                                                                                                                 // 45
                                                                                                                    //
// publish stranger user info only the profile seed for profile picture.                                            //
Meteor.publish("users/strangersInfo", function (strangers) {                                                        // 48
  if (!this.userId) return this.ready();                                                                            // 49
                                                                                                                    //
  return Meteor.users.find({ "_id": { "$in": strangers } }, {                                                       // 52
    "fields": {                                                                                                     // 54
      "profile.profileSeed": 1,                                                                                     // 55
      "profile.savedTags": 1                                                                                        // 56
    }                                                                                                               // 54
  });                                                                                                               // 53
});                                                                                                                 // 59
                                                                                                                    //
// publish only one stranger info                                                                                   //
Meteor.publish("users/getStrangerProfile", function (strangerId) {                                                  // 62
  return Meteor.users.find(strangerId, {                                                                            // 63
    "fields": {                                                                                                     // 64
      "profile.profileSeed": 1,                                                                                     // 65
      "profile.savedTags": 1                                                                                        // 66
    }                                                                                                               // 64
  });                                                                                                               // 63
});                                                                                                                 // 69
                                                                                                                    //
Meteor.publish("users/getSingleTag", function (tagId) {                                                             // 71
  console.log("Sub " + tagId);                                                                                      // 72
  var tag = App.Collections.Tags.findOne(tagId);                                                                    // 73
  if (tag) {                                                                                                        // 74
    var users = tag.users;                                                                                          // 75
    return [App.Collections.Tags.find(tagId), Meteor.users.find({                                                   // 76
      "_id": { "$in": users }                                                                                       // 78
    }, {                                                                                                            // 77
      "fields": {                                                                                                   // 80
        "profile.profileSeed": 1                                                                                    // 81
      }                                                                                                             // 80
    })];                                                                                                            // 79
  }                                                                                                                 // 84
});                                                                                                                 // 85
                                                                                                                    //
Meteor.publish("users/profilePicUnderTag", function (tagId) {                                                       // 87
  var tag = App.Collections.Tags.findOne(tagId);                                                                    // 88
  if (tag) {                                                                                                        // 89
    var users = tag.users;                                                                                          // 90
    return Meteor.users.find({                                                                                      // 91
      "_id": { "$in": users }                                                                                       // 92
    }, {                                                                                                            // 91
      "fields": {                                                                                                   // 94
        "profile.profileSeed": 1                                                                                    // 95
      }                                                                                                             // 94
    });                                                                                                             // 93
  }                                                                                                                 // 98
});                                                                                                                 // 99
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"wifis.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/publications/wifis.js                                                                                     //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
Meteor.publish("wifis/nearbyWifis", function (wifiList) {                                                           // 1
  for (var index = 0; index < 5; index++) {                                                                         // 2
    if (!wifiList[index]) break;                                                                                    // 3
                                                                                                                    //
    if (!App.Collections.Wifis.findOne({ bssid: wifiList[index].bssid })) {                                         // 5
      App.Collections.Wifis.insert({                                                                                // 6
        ssid: wifiList[index].ssid,                                                                                 // 7
        bssid: wifiList[index].bssid,                                                                               // 8
        tags: []                                                                                                    // 9
      });                                                                                                           // 6
    }                                                                                                               // 11
  }                                                                                                                 // 12
                                                                                                                    //
  var wifiIdList = wifiList.map(function (wifi) {                                                                   // 14
    return wifi.bssid;                                                                                              // 14
  });                                                                                                               // 14
  return App.Collections.Wifis.find({ bssid: { $in: wifiIdList } });                                                // 15
});                                                                                                                 // 16
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"seed":{"seed_settings.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/seed/seed_settings.js                                                                                     //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
/**                                                                                                                 //
 * Seed settings collection, if settings collection is found empty                                                  //
 */                                                                                                                 //
App.Seeder.Settings = function () {                                                                                 // 4
                                                                                                                    //
  if (App.Collections.Settings.find().count() == 0) {                                                               // 6
                                                                                                                    //
    var smtpSettings = {                                                                                            // 8
      smtpAddress: "smtp.gmail.com",                                                                                // 9
      smtpPort: "465",                                                                                              // 10
      smtpUsername: "noreply.submarine.cse110@gmail.com",                                                           // 11
      smtpPassword: "asdfqwer",                                                                                     // 12
      smtpAuthentication: "tls/ssl"                                                                                 // 13
    };                                                                                                              // 8
                                                                                                                    //
    App.Collections.Settings.insert(smtpSettings);                                                                  // 16
  }                                                                                                                 // 17
};                                                                                                                  // 18
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"seed_tags.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/seed/seed_tags.js                                                                                         //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
/**                                                                                                                 //
 * Seed tags collection, for dev                                                                                    //
 */                                                                                                                 //
App.Seeder.Tags = function () {                                                                                     // 4
  console.log("start tag");                                                                                         // 5
  if (!App.Collections.Tags.findOne({ "name": "Earth" })) {                                                         // 6
    var test1 = App.Collections.Wifis.findOne({ "ssid": "test1" });                                                 // 7
    var test2 = App.Collections.Wifis.findOne({ "ssid": "test2" });                                                 // 8
    var test3 = App.Collections.Wifis.findOne({ "ssid": "test5" });                                                 // 9
                                                                                                                    //
    App.Collections.Tags.insert({                                                                                   // 11
      name: "Earth",                                                                                                // 12
      description: "Channel Earthlings all subscribe to",                                                           // 13
      wifis: [{ "wifiId": test1._id, "level": -40 }, { "wifiId": test2._id, "level": -50 }, { "wifiId": test3._id, "level": -55 }],
      startTime: 0,                                                                                                 // 15
      duration: 1440,                                                                                               // 16
      users: [],                                                                                                    // 17
      repeat: 255                                                                                                   // 18
    }, function (err, res) {                                                                                        // 11
      if (err) {                                                                                                    // 20
        console.log(JSON.stringify(err, undefined, 2));                                                             // 21
        return;                                                                                                     // 22
      }                                                                                                             // 23
                                                                                                                    //
      App.Collections.Wifis.update(test1._id, { "$push": { "tags": res } });                                        // 25
      App.Collections.Wifis.update(test2._id, { "$push": { "tags": res } });                                        // 26
      App.Collections.Wifis.update(test3._id, { "$push": { "tags": res } });                                        // 27
    });                                                                                                             // 28
  }                                                                                                                 // 29
                                                                                                                    //
  if (!App.Collections.Tags.findOne({ "name": "Mars" })) {                                                          // 31
    var test4 = App.Collections.Wifis.findOne({ "ssid": "test2" });                                                 // 32
    var test5 = App.Collections.Wifis.findOne({ "ssid": "test3" });                                                 // 33
    var test6 = App.Collections.Wifis.findOne({ "ssid": "test5" });                                                 // 34
                                                                                                                    //
    App.Collections.Tags.insert({                                                                                   // 36
      name: "Mars",                                                                                                 // 37
      description: "Channel Martians all subscribe to",                                                             // 38
      wifis: [{ "wifiId": test4._id, "level": -50 }, { "wifiId": test5._id, "level": -50 }, { "wifiId": test6._id, "level": -55 }],
      startTime: 0,                                                                                                 // 40
      duration: 1440,                                                                                               // 41
      users: [],                                                                                                    // 42
      repeat: 255                                                                                                   // 43
    }, function (err, res) {                                                                                        // 36
      if (err) {                                                                                                    // 45
        console.log(JSON.stringify(err, undefined, 2));                                                             // 46
        return;                                                                                                     // 47
      }                                                                                                             // 48
                                                                                                                    //
      App.Collections.Wifis.update(test4._id, { "$push": { "tags": res } });                                        // 50
      App.Collections.Wifis.update(test5._id, { "$push": { "tags": res } });                                        // 51
      App.Collections.Wifis.update(test6._id, { "$push": { "tags": res } });                                        // 52
    });                                                                                                             // 53
  }                                                                                                                 // 54
                                                                                                                    //
  if (!App.Collections.Tags.findOne({ "name": "Moon" })) {                                                          // 56
    var test7 = App.Collections.Wifis.findOne({ "ssid": "test1" });                                                 // 57
    var test8 = App.Collections.Wifis.findOne({ "ssid": "test3" });                                                 // 58
    var test9 = App.Collections.Wifis.findOne({ "ssid": "test5" });                                                 // 59
                                                                                                                    //
    App.Collections.Tags.insert({                                                                                   // 61
      name: "Moon",                                                                                                 // 62
      description: "Channel Lunarians all subscribe to",                                                            // 63
      wifis: [{ "wifiId": test7._id, "level": -40 }, { "wifiId": test8._id, "level": -50 }, { "wifiId": test9._id, "level": -45 }],
      start_time: 0,                                                                                                // 65
      end_time: 1440,                                                                                               // 66
      users: [],                                                                                                    // 67
      repeat: 255                                                                                                   // 68
    }, function (err, res) {                                                                                        // 61
      if (err) {                                                                                                    // 70
        console.log(JSON.stringify(err, undefined, 2));                                                             // 71
        return;                                                                                                     // 72
      }                                                                                                             // 73
                                                                                                                    //
      App.Collections.Wifis.update(test7._id, { "$push": { "tags": res } });                                        // 75
      App.Collections.Wifis.update(test8._id, { "$push": { "tags": res } });                                        // 76
      App.Collections.Wifis.update(test9._id, { "$push": { "tags": res } });                                        // 77
    });                                                                                                             // 78
  }                                                                                                                 // 79
};                                                                                                                  // 80
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"seed_users.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/seed/seed_users.js                                                                                        //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
/**                                                                                                                 //
 * Seed users collection, for testing                                                                               //
 */                                                                                                                 //
App.Seeder.Users = function () {                                                                                    // 4
                                                                                                                    //
  if (!Accounts.findUserByUsername("Ensign")) {                                                                     // 6
    Accounts.createUser({                                                                                           // 7
      username: "Ensign",                                                                                           // 8
      email: "ensign@aa.aa",                                                                                        // 9
      password: "asdfqwer"                                                                                          // 10
    });                                                                                                             // 7
  }                                                                                                                 // 12
                                                                                                                    //
  if (!Accounts.findUserByUsername("Lieutenant")) {                                                                 // 14
    Accounts.createUser({                                                                                           // 15
      username: "Lieutenant",                                                                                       // 16
      email: "Lieutenant@aa.aa",                                                                                    // 17
      password: "asdfqwer"                                                                                          // 18
    });                                                                                                             // 15
  }                                                                                                                 // 20
                                                                                                                    //
  if (!Accounts.findUserByUsername("Commander")) {                                                                  // 22
    Accounts.createUser({                                                                                           // 23
      username: "Commander",                                                                                        // 24
      email: "Commander@aa.aa",                                                                                     // 25
      password: "asdfqwer"                                                                                          // 26
    });                                                                                                             // 23
  }                                                                                                                 // 28
                                                                                                                    //
  if (!Accounts.findUserByUsername("Captain")) {                                                                    // 30
    Accounts.createUser({                                                                                           // 31
      username: "Captain",                                                                                          // 32
      email: "Captain@aa.aa",                                                                                       // 33
      password: "asdfqwer"                                                                                          // 34
    });                                                                                                             // 31
  }                                                                                                                 // 36
                                                                                                                    //
  if (!Accounts.findUserByUsername("Admiral")) {                                                                    // 38
    Accounts.createUser({                                                                                           // 39
      username: "Admiral",                                                                                          // 40
      email: "Admiral@aa.aa",                                                                                       // 41
      password: "asdfqwer"                                                                                          // 42
    });                                                                                                             // 39
  }                                                                                                                 // 44
                                                                                                                    //
  if (!Accounts.findUserByUsername("JohnD")) {                                                                      // 46
    Accounts.createUser({                                                                                           // 47
      username: "JohnD",                                                                                            // 48
      email: "JohnD@aa.aa",                                                                                         // 49
      password: "asdfqwer"                                                                                          // 50
    });                                                                                                             // 47
  }                                                                                                                 // 52
                                                                                                                    //
  if (!Accounts.findUserByUsername("JaneD")) {                                                                      // 54
    Accounts.createUser({                                                                                           // 55
      username: "JaneD",                                                                                            // 56
      email: "JaneD@aa.aa",                                                                                         // 57
      password: "asdfqwer"                                                                                          // 58
    });                                                                                                             // 55
  }                                                                                                                 // 60
};                                                                                                                  // 61
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"seed_wifi.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/seed/seed_wifi.js                                                                                         //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
/**                                                                                                                 //
 * Seed wifis collection, for dev                                                                                   //
 */                                                                                                                 //
App.Seeder.Wifis = function () {                                                                                    // 4
                                                                                                                    //
  if (!App.Collections.Wifis.findOne({ ssid: "test1" })) {                                                          // 6
    App.Collections.Wifis.insert({                                                                                  // 7
      ssid: "test1",                                                                                                // 8
      bssid: "11:22:33:44:55:66:77:88",                                                                             // 9
      tags: []                                                                                                      // 10
    });                                                                                                             // 7
  }                                                                                                                 // 12
                                                                                                                    //
  if (!App.Collections.Wifis.findOne({ ssid: "test2" })) {                                                          // 14
    App.Collections.Wifis.insert({                                                                                  // 15
      ssid: "test2",                                                                                                // 16
      bssid: "22:33:44:55:66:77:88:99",                                                                             // 17
      tags: []                                                                                                      // 18
    });                                                                                                             // 15
  }                                                                                                                 // 20
                                                                                                                    //
  if (!App.Collections.Wifis.findOne({ ssid: "test3" })) {                                                          // 22
    App.Collections.Wifis.insert({                                                                                  // 23
      ssid: "test3",                                                                                                // 24
      bssid: "33:44:55:66:77:88:99:aa",                                                                             // 25
      tags: []                                                                                                      // 26
    });                                                                                                             // 23
  }                                                                                                                 // 28
                                                                                                                    //
  if (!App.Collections.Wifis.findOne({ ssid: "test4" })) {                                                          // 30
    App.Collections.Wifis.insert({                                                                                  // 31
      ssid: "test4",                                                                                                // 32
      bssid: "44:55:66:77:88:99:aa:bb",                                                                             // 33
      tags: []                                                                                                      // 34
    });                                                                                                             // 31
  }                                                                                                                 // 36
                                                                                                                    //
  if (!App.Collections.Wifis.findOne({ ssid: "test5" })) {                                                          // 38
    App.Collections.Wifis.insert({                                                                                  // 39
      ssid: "test5",                                                                                                // 40
      bssid: "55:66:77:88:99:aa:bb:cc",                                                                             // 41
      tags: []                                                                                                      // 42
    });                                                                                                             // 39
  }                                                                                                                 // 44
                                                                                                                    //
  console.log("end wifi");                                                                                          // 46
};                                                                                                                  // 47
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"init.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/init.js                                                                                                   //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
// Server-side init scripts                                                                                         //
Meteor.startup(function () {                                                                                        // 2
                                                                                                                    //
  process.env.ROOT_URL = 'http://104.236.147.136:3000/';                                                            // 4
  process.env.MOBILE_ROOT_URL = 'http://104.236.147.136:3000/';                                                     // 5
  process.env.MOBILE_DDP_URL = 'http://104.236.147.136:3000/';                                                      // 6
                                                                                                                    //
  // seeding database                                                                                               //
  // App.Seeder.Settings();                                                                                         //
  // App.Seeder.Wifis();                                                                                            //
  // App.Seeder.Tags();                                                                                             //
  // App.Seeder.Users();                                                                                            //
                                                                                                                    //
  // initialized essential Settings                                                                                 //
  // App.Initializer.SMTP();                                                                                        //
  // App.Initializer.configureResetEmail();                                                                         //
});                                                                                                                 // 17
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{"extensions":[".js",".json"]});
require("./common/collections/message.js");
require("./common/collections/settings.js");
require("./common/collections/tags.js");
require("./common/collections/users.js");
require("./common/collections/wifis.js");
require("./common/methods/chats.js");
require("./common/methods/friends.js");
require("./common/methods/tags.js");
require("./common/methods/users.js");
require("./common/services/notification.js");
require("./server/accounts/accounts_config.js");
require("./server/mail/init_mail.js");
require("./server/publications/chat.js");
require("./server/publications/messages.js");
require("./server/publications/tags.js");
require("./server/publications/users.js");
require("./server/publications/wifis.js");
require("./server/seed/seed_settings.js");
require("./server/seed/seed_tags.js");
require("./server/seed/seed_users.js");
require("./server/seed/seed_wifi.js");
require("./server/init.js");
//# sourceMappingURL=app.js.map
